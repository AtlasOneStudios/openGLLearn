Escape : Unlock cursor

 	 When in full screen: Un-fullscreen



Mouse   : Look around

W       : Forward

A       : Strafe left

S       : Backward

D       : Strafe right

Spacebar: Jump



Window *is* resizable

